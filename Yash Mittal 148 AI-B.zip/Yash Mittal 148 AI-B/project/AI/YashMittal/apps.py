from django.apps import AppConfig


class YashMittalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'YashMittal'
